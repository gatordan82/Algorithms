

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

/**
 * @author Dan
 *
 */

public class Percolation 
{
	private boolean[][] grid;
	private boolean[] connectedToBottom;
	private int size;
	private WeightedQuickUnionUF uf;
	private int virtualTop;
	
	private void validateCoords(int i, int j)
	{
        if (i < 1 || i > this.size)
        {
            throw new IndexOutOfBoundsException("Index i is not between 1 and " + this.size);
        }
        if (j < 1 || j > this.size)
        {
            throw new IndexOutOfBoundsException("Index j is not between 1 and " + this.size);
        }
	}
	
	private int coordsToUF(int i, int j)
	{
		return (i - 1) * this.size + (j - 1);
	}

		
	public Percolation(int N)
	{
		if (N <= 0) throw new IllegalArgumentException("Size of Percolation grid isn't > 0");
		
		this.size     = N;
		this.grid     = new boolean[N][N];
		this.connectedToBottom = new boolean[N * N + 1];
		this.uf       = new WeightedQuickUnionUF(N * N + 1);
		
		this.virtualTop = N * N;
	}
	
	public void open(int i, int j)
	{
	    validateCoords(i, j);
	    
		//open the site
		if (!isOpen(i, j)) 
		{
		    grid[i - 1][j - 1] = true;
		    
		    //connect any open, adjacent neighbors
	        int p = coordsToUF(i, j);
	        
            if (i == 1)
            {
                this.uf.union(p, this.virtualTop);
            }
	        
	        if (i == this.size) 
            {
	            this.connectedToBottom[this.uf.find(p)] = true;
            }
	               
	        //neighbor to the left
	        if (j > 1) unionIfOpen(i, j - 1, p);
	        //neighbor to the right
	        if (j < this.size) unionIfOpen(i, j + 1, p);
	        //neighbor above
	        if (i > 1) unionIfOpen(i - 1, j, p);
	        //neighbor below
            if (i < this.size) unionIfOpen(i + 1, j, p);
		}
	}
	
    private void unionIfOpen(int i, int j, int p)
    {
        int q = coordsToUF(i, j);
        
        if (isOpen(i, j) && !this.uf.connected(p, q))
        {
            int rootQ = this.uf.find(q);
            int rootP = this.uf.find(p);
            if (this.connectedToBottom[rootQ] || this.connectedToBottom[rootP])
            {
                this.connectedToBottom[rootP] = true;
                this.connectedToBottom[rootQ] = true;
            }
            this.uf.union(p, q);
        }       
    }
	
	public boolean isOpen(int i, int j)
	{
	    validateCoords(i, j);
	    
		return grid[i - 1][j - 1];
	}
	
	public boolean isFull(int i, int j)
	{
	    validateCoords(i, j);
	    int p = coordsToUF(i, j);

		return this.uf.connected(p, this.virtualTop);
	}
	
	public boolean percolates()
	{
	    int root = this.uf.find(virtualTop);
	    return this.connectedToBottom[root];
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{

	}

}
